package com.example.java8scratch;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

public class Main {

  public static void main(String[] args) throws IOException {

    QuestionTwo questionTwo = new ObjectMapper().readValue(
        Main.class.getClassLoader().getResourceAsStream("question2.json"), QuestionTwo.class);
    DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols();
    decimalFormatSymbols.setGroupingSeparator('.');
    DecimalFormat decimalFormat = new DecimalFormat("#,###,###");
    decimalFormat.setDecimalFormatSymbols(decimalFormatSymbols);

    assert questionTwo.getOrderNumber().getClass().getName()
        .equalsIgnoreCase("java.lang.Integer") : String.format("Test Failed, Data Type is %s",
        questionTwo.getOrderNumber().getClass().getName());

    assert questionTwo.getTotal() == 52000000 : String.format(
        "Test Failed, Total Rp %s is false, total is must be Rp 52.000.000",
        decimalFormat.format(questionTwo.getTotal()));
  }

  @Data
  @NoArgsConstructor
  @AllArgsConstructor
  public static class QuestionTwo {

    private String name;
    private String orderNumber;
    private String courier;
    private List<QuestionTwoItem> product;
    private Integer total;
    private Integer code;
    private Boolean success;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class QuestionTwoItem {

      private String item;
      private Integer price;
    }
  }
}
